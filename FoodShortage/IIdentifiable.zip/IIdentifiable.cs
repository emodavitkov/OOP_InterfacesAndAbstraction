﻿namespace FoodShortage
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}