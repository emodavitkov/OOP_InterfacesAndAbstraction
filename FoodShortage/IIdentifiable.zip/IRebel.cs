﻿namespace FoodShortage
{
    public interface IRebel : IPerson
    {
        public string Group { get; set; }
    }
}
