﻿using MilitaryElite;

public class Enums
{
    public enum Corp
    {
        Airforces,
        Marines
    }

    public enum State
    {
        inProgress,
        Finished
    }
}
