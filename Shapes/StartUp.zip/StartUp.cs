﻿namespace Shapes
{
    public class StartUp
    {
        
    }
}